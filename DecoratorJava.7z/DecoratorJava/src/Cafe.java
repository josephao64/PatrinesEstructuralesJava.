//Se define la interfaz Cafe, que actúa como el componente base. En este caso, solo tiene un método costo()
// que devuelve el costo del café.
public interface Cafe {
    double costo();
}
