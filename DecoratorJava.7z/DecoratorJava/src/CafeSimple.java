//Se define la clase CafeSimple que implementa la interfaz Cafe. Esta clase representa
// un café simple y proporciona una implementación con un costo base de 5.

public class CafeSimple implements Cafe{
    @Override
    public double costo() {
        return 5; //costo base del cafe
    }
}
