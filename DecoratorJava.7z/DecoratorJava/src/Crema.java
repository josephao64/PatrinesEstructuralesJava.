public class Crema extends DecoratorCafe{
    public Crema (Cafe cafe){
        super(cafe);

    }

    @Override
    public double costo() {
        return super.costo() + 3;
    }
}
