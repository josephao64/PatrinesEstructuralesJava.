//Se define la clase abstracta DecoradorCafe que también implementa la interfaz Cafe.
// Esta clase actúa como la base para los decoradores concretos. Tiene un miembro protegido cafe
// que guarda una referencia al objeto Cafe que será decorado. El método costo() se implementa
// aquí para devolver el costo del café original.
abstract public class DecoratorCafe implements Cafe{
    protected Cafe cafe;

    public DecoratorCafe (Cafe cafe){ //constructor
        this.cafe = cafe;
    }

    @Override
    public double costo() {
        return cafe.costo();
    }
}
