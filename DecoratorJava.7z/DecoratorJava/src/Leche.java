//Se definen las clases concretas de decoradores, como Leche y Crema.
// Cada una de estas clases hereda de DecoradorCafe y anulan el metodo costo() para llamar super.costo() así obtener el costo original.
// En este caso, cada decorador agrega un costo adicional al costo base del café original.

public class Leche extends DecoratorCafe {
    public Leche (Cafe cafe){
        super(cafe);

    }

    @Override
    public double costo() {
        return super.costo() + 2;
    }
}
