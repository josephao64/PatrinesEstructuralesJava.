//En la clase Main, se realiza el uso y la combinación de los objetos Cafe y decoradores.
// Se crean instancias de objetos CafeSimple, Leche, Crema y se combinan para crear diferentes variantes de café
// con diferentes costos.
public class Main {
    public static void main(String[] args) {

        Cafe cafeSimple = new CafeSimple();
        System.out.println("Café simple: Q" + cafeSimple.costo());

        Cafe cafeConLeche = new Leche(cafeSimple);
        System.out.println("Café con leche: Q" + cafeConLeche.costo());

        Cafe cafeConCrema = new Crema(cafeSimple);
        System.out.println("Café con crema: Q" + cafeConCrema.costo());

        Cafe cafeDecorado = new Crema(new Leche(cafeSimple));
        System.out.println("Café con leche y crema: Q" + cafeDecorado.costo());





    }
}