public class FabricaDeChurros {
    //metodos para iniciar la fabrica
    void abrirPuertas (){
        System.out.println( "abriendo puertas");


    }
    void limpiarMaquina (){
        System.out.println("limpiando maquina");

    }
    void iniciarMaquina (){
        System.out.println("iniciando maquina");
    }
    // metodos para cerrar la fabrica
    void cerrarPuertas(){
        System.out.println("cerrando puertas");
    }
    void apagarMaquina (){
        System.out.println("apagnado maquina");
    }
}
