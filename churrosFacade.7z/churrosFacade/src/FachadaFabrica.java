public class FachadaFabrica {
    FabricaDeChurros fabricaDeChurros;

    FachadaFabrica (FabricaDeChurros cf){
        fabricaDeChurros = cf;
    }
    void iniciarFabrica(){
        fabricaDeChurros.abrirPuertas();
        fabricaDeChurros.limpiarMaquina();
        fabricaDeChurros.iniciarMaquina();
    }
    void cerrarFabrica(){
        fabricaDeChurros.limpiarMaquina();
        fabricaDeChurros.apagarMaquina();
        fabricaDeChurros.cerrarPuertas();

    }
}
