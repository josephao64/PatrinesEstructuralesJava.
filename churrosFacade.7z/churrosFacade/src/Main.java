public class Main {
    public static void main(String[] args) {
        FabricaDeChurros fabricaDeChurros = new FabricaDeChurros();
        // este codigo tendria que hacer el cliente si no hubira facade
        System.out.println("--- Fabrica de churro ---");
        System.out.println("iniciando fabrica de churros");
        fabricaDeChurros.abrirPuertas();
        fabricaDeChurros.limpiarMaquina();
        fabricaDeChurros.iniciarMaquina();
        System.out.println("--------------------------");
        System.out.println("cerrando fabrica de churros");
        fabricaDeChurros.limpiarMaquina();
        fabricaDeChurros.apagarMaquina();
        fabricaDeChurros.cerrarPuertas();


        //facade
        FachadaFabrica fachadaFabrica = new FachadaFabrica(fabricaDeChurros);
        System.out.println("--- fabrica de churros fachada ---");
        System.out.println("iniciando fabrica de churros (fachada)");
        fachadaFabrica.iniciarFabrica();
        System.out.println("-------------------------");
        System.out.println("cerrando fabrica de churros (fachada)");
        fachadaFabrica.cerrarFabrica();





    }
}